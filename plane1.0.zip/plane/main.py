import pygame
import sys
import math
import os
import copy
import random

# 界面图片
startImgs = [
    pygame.transform.scale(pygame.image.load('image/startImgs/back.jpg'), (506, 900)),
   # pygame.image.load('image/startImgs/start.png'),
   # pygame.image.load('image/startImgs/name.png'),
    pygame.image.load('image/startImgs/loading.png'),
    pygame.transform.scale(pygame.image.load('image/startImgs/back2.jpg'), (506, 900)),
    pygame.image.load('image/startImgs/endName.png'),
    #pygame.image.load('image/startImgs/start2.png'),
]

# 按钮背景图片
buttonImgs = [
    pygame.image.load('image/buttonImgs/ring1.png'),
    pygame.image.load('image/buttonImgs/ring2.png')
]

# 蓝色飞船图片
shipBlue = [
    pygame.image.load('image/shipBlue/ship1.png'),
    pygame.image.load('image/shipBlue/ship2.png'),
    pygame.image.load('image/shipBlue/ship3.png'),
    pygame.image.load('image/shipBlue/ship4.png'),
    pygame.image.load('image/shipBlue/ship5.png'),
    pygame.image.load('image/shipBlue/ship6.png'),
    pygame.image.load('image/shipBlue/ship7.png'),
    pygame.image.load('image/shipBlue/ship8.png'),
    pygame.image.load('image/shipBlue/ship9.png'),
    pygame.image.load('image/shipBlue/ship9.png'),
    pygame.image.load('image/shipBlue/ship8.png'),
    pygame.image.load('image/shipBlue/ship7.png'),
    pygame.image.load('image/shipBlue/ship6.png'),
    pygame.image.load('image/shipBlue/ship5.png'),
    pygame.image.load('image/shipBlue/ship4.png'),
    pygame.image.load('image/shipBlue/ship3.png'),
    pygame.image.load('image/shipBlue/ship2.png'),
    pygame.image.load('image/shipBlue/ship1.png'),
]

# 红色飞船图片
shipRed = [
    pygame.image.load('image/shipRed/ship11.png'),
    pygame.image.load('image/shipRed/ship12.png'),
    pygame.image.load('image/shipRed/ship13.png'),
    pygame.image.load('image/shipRed/ship01.png'),
    pygame.image.load('image/shipRed/ship02.png'),
    pygame.image.load('image/shipRed/ship03.png'),
]

# 子弹图片
bulletImgs = [
    pygame.image.load('image/bulletImgs/bullet3.png')
]
bulletList = []

# 敌机图片
enemyImgs = [
    pygame.image.load('image/enemyImgs/enemy11.png'),
    pygame.image.load('image/enemyImgs/enemy22.png'),
    pygame.image.load('image/enemyImgs/enemy3.png'),
    pygame.image.load('image/enemyImgs/enemy4.png'),
]
enemy1Imgs = [
    pygame.image.load('image/enemy1/enemy11.png'),
    pygame.image.load('image/enemy1/enemy12.png'),
    pygame.image.load('image/enemy1/enemy13.png'),
    pygame.image.load('image/enemy1/enemy14.png'),
    pygame.image.load('image/enemy1/enemy15.png')
]
enemy2Imgs = [
    pygame.image.load('image/enemy2/enemy21.png'),
    pygame.image.load('image/enemy2/enemy22.png'),
    pygame.image.load('image/enemy2/enemy23.png'),
    pygame.image.load('image/enemy2/enemy24.png'),
    pygame.image.load('image/enemy2/enemy25.png')
]
enemy3Imgs = [
    pygame.image.load('image/enemy3/enemy31.png'),
    pygame.image.load('image/enemy3/enemy32.png'),
    pygame.image.load('image/enemy3/enemy33.png'),
    pygame.image.load('image/enemy3/enemy34.png'),
    pygame.image.load('image/enemy3/enemy35.png')
]
enemy4Imgs = [
    pygame.image.load('image/enemy4/enemy41.png'),
    pygame.image.load('image/enemy4/enemy42.png'),
    pygame.image.load('image/enemy4/enemy43.png'),
    pygame.image.load('image/enemy4/enemy44.png'),
    pygame.image.load('image/enemy4/enemy45.png')
]

enemyList = []

# 奖励图片
awardImgs = [
    pygame.image.load('image/award/award1.png'),
    pygame.image.load('image/award/award2.png'),
    pygame.image.load('image/award/award3.png'),
]
award1 = [
    pygame.image.load('image/award1/award11.png'),
    pygame.image.load('image/award1/award12.png'),
    pygame.image.load('image/award1/award13.png'),
    pygame.image.load('image/award1/award14.png'),
    pygame.image.load('image/award1/award15.png')
]
award2 = [
    pygame.image.load('image/award2/award21.png'),
    pygame.image.load('image/award2/award22.png'),
    pygame.image.load('image/award2/award23.png'),
    pygame.image.load('image/award2/award24.png'),
    pygame.image.load('image/award2/award25.png')
]

# 初始化mixer
pygame.mixer.init()
# 音乐列表
musicList = [
    pygame.mixer.Sound('music/distroy1.ogg'),
    pygame.mixer.Sound('music/distroy2.ogg'),
    pygame.mixer.Sound('music/distroy3.ogg'),
    pygame.mixer.Sound('music/distroy4.ogg'),
    pygame.mixer.Sound('music/bullet1.ogg'),
    pygame.mixer.Sound('music/protect.ogg')
]


# 界面
class StartPlane:
    isInside = False

    # 初始化图片
    def __init__(self, screen):
        """
        :param screen:渲染的屏幕
        :param startImgs:开始背景图
        """
        self.screen = screen
        self.startImgs = startImgs
        self.buttonImgs = buttonImgs
        self.shipBlue = shipBlue

        self.index = 0
        self.imgAddIndex = 0
        self.imgBlueShip = 0
        self.btmImgIndex = 0

    # 开始界面
    def StartDisp(self):
        self.index += 0.07
        if self.index == 1000:
            self.index = 0

        # 背景图
        self.screen.blit(self.startImgs[0], (0, 0))

        # 加载图
        self.screen.blit(self.startImgs[3], (0, 165))

        # 标题
        self.screen.blit(pygame.transform.scale(self.startImgs[2], (406, 267)),
                         (50 + 15 * math.sin(self.index), 50 - 15 * math.cos(self.index)))

        # 帧数计算
        self.imgAddIndex += 1
        if self.imgAddIndex == 1000:
            self.imgAddIndex = 0

        # 蓝色飞船
        if self.imgAddIndex % 10 == 0:
            self.imgBlueShip += 1
            if self.imgBlueShip == 18:
                self.imgBlueShip = 0
        btn = self.screen.blit(self.shipBlue[self.imgBlueShip], (177, 320))

        # # 按钮背景w
        # if self.imgAddIndex % 15 == 0:
        #     self.btmImgIndex += 1
        #     if self.btmImgIndex == 2:
        #         self.btmImgIndex = 0
        # self.screen.blit(self.buttonImgs[self.btmImgIndex], (125, 543))

        # 按钮
        # self.screen.blit(self.startImgs[1], (173, 650))

        # 判断鼠标是否在按钮上
        StartPlane.isInside = btn.collidepoint(pygame.mouse.get_pos())

    # 结束画面
    def EndDisp(self):
        # 背景图
        self.screen.blit(self.startImgs[4], (0, 0))

        # 标题
        self.screen.blit(self.startImgs[5], (60, 150))

        # 按钮
        # 帧数计算
        self.imgAddIndex += 1
        if self.imgAddIndex == 1000:
            self.imgAddIndex = 0

        # 蓝色飞船
        if self.imgAddIndex % 10 == 0:
            self.imgBlueShip += 1
            if self.imgBlueShip == 18:
                self.imgBlueShip = 0
        btn = self.screen.blit(self.shipBlue[self.imgBlueShip], (177, 500))

        # 判断鼠标是否在按钮上
        StartPlane.isInside = btn.collidepoint(pygame.mouse.get_pos())


# 背景移动
class BackGround:
    def __init__(self, img, speed, screen):
        self.img1 = img
        self.img1rect = self.img1.get_rect()
        self.img2 = copy.copy(self.img1)
        self.img2rect = self.img2.get_rect()
        self.img2rect.y = -900

        self.speed = speed
        self.screen = screen

    def Move(self):
        self.img1rect = self.img1rect.move(0, self.speed)
        self.img2rect = self.img2rect.move(0, self.speed)

        if self.img1rect.y >= 910:
            self.img1rect.y = self.img2rect.y - 900
        if self.img2rect.y >= 910:
            self.img2rect.y = self.img1rect.y - 900

        self.screen.blit(self.img1, self.img1rect)
        self.screen.blit(self.img2, self.img2rect)


# 英雄类
class Hero(pygame.sprite.Sprite):
    up = False
    down = False
    left = False
    right = False
    turn = 4
    Score = 0
    Boom = 0
    protect = False


    # 属性：图片，初始位置，血量，速度，屏幕
    def __init__(self, imgs, pos, hp, speed, screen):
        self.imgs = imgs
        self.image = self.imgs[1]
        # 飞船的矩形区域
        self.rect = self.imgs[1].get_rect()
        # 飞船左上角的坐标
        self.rect.topleft = pos
        self.hp = hp
        self.speed = speed
        self.screen = screen

        self.indexAdd = 1
        self.indexPro = 0

    # 行为：移动
    def Move(self):
        # 上下左右四个方向
        if Hero.up:
            self.rect = self.rect.move(0, -self.speed)
        if Hero.down:
            self.rect = self.rect.move(0, self.speed)
        if Hero.left:
            self.rect = self.rect.move(-self.speed, 0)
        if Hero.right:
            self.rect = self.rect.move(self.speed, 0)

        # 约束移动区域
        if self.rect.x <= 0:
            self.rect.x = 0
        if self.rect.x >= (self.screen.get_width() - self.imgs[1].get_width()):
            self.rect.x = self.screen.get_width() - self.imgs[1].get_width()
        if self.rect.y <= 0:
            self.rect.y = 0
        if self.rect.y >= (self.screen.get_height() - self.imgs[1].get_height()):
            self.rect.y = self.screen.get_height() - self.imgs[1].get_height()

        # 增加护盾
        if self.protect == True:
            self.indexPro += 1
            # 右移图片
            if self.right == True:
                self.imgIndex = 5
            # 左移图片
            elif self.left == True:
                self.imgIndex = 3
            else:
                self.imgIndex = 4
            # 渲染图像
            self.screen.blit(self.imgs[self.imgIndex], self.rect)

            self.Built()

            self.Collide()

            if self.indexPro == 300:
                global protect
                Hero.protect = False
                self.indexPro = 0

        else:
            # 右移图片
            if self.right == True:
                self.imgIndex = 2
            # 左移图片
            elif self.left == True:
                self.imgIndex = 0
            else:
                self.imgIndex = 1
            # 渲染图像
            self.screen.blit(self.imgs[self.imgIndex], self.rect)

            self.Built()

            self.Collide()

            self.Dead()

    # 发射子弹
    def Built(self):
        self.indexAdd += 1
        if self.indexAdd == 1000:
            self.indexAdd = 0

        if self.indexAdd % 12 == 0:
            musicList[4].play()
            Bullet(bulletImgs[0], (self.rect.centerx - (bulletImgs[0].get_width() / 2), self.rect.y),
                   6, self.screen)

        # 子弹移动
        for i in bulletList:
            if i != None and isinstance(i, Bullet):
                i.Move()

    # 碰撞敌机
    def Collide(self, target=enemyList):
        # collided=pygame.sprite.collide_mask  打开碰撞遮罩
        tempEnemy = pygame.sprite.spritecollideany(self, target, collided=pygame.sprite.collide_mask)
        # 如果英雄碰撞的敌机在敌机列表中
        if tempEnemy in enemyList:
            if tempEnemy.tag.startswith('enemy') and self.protect == False:
                self.hp -= 1
                # 回归初始位置
                self.rect.topleft = (202, 689)
                tempEnemy.hp -= 5
            else:
                tempEnemy.hp -= 15

    # 死亡
    def Dead(self):
        global isPlay
        if self.hp <= 0:
            History.UpdateHistory(Hero.Score)
            isPlay = 2


# 子弹类
class Bullet(pygame.sprite.Sprite):
    # 属性：图片，位置，速度，屏幕;
    def __init__(self, img, pos, speed, screen):
        self.image = img
        # 子弹矩形区域
        self.rect = self.image.get_rect()
        # 子弹左上坐标
        self.rect.topleft = pos
        self.speed = speed
        self.screen = screen
        bulletList.append(self)

    # 行为：移动
    def Move(self):
        self.rect = self.rect.move(0, -self.speed)
        self.screen.blit(self.image, self.rect)
        if self.rect.y <= -96:
            if self in bulletList:
                bulletList.remove(self)
        self.CollideEnemy()

    # 碰撞
    def CollideEnemy(self, target=enemyList):
        # collided=pygame.sprite.collide_mask  打开碰撞遮罩
        tempEnemy = pygame.sprite.spritecollideany(self, target, collided=pygame.sprite.collide_mask)
        # 如果子弹碰撞的敌机在敌机列表中，并且该子弹在子弹列表中
        if tempEnemy in enemyList and self in bulletList:
            # 从子弹列表中移除该子弹
            bulletList.remove(self)
            # 被碰撞的敌机血量减1
            tempEnemy.hp -= 1


# 敌机类
class Enemy(pygame.sprite.Sprite):
    # 属性：图片，位置，血量，速度，屏幕，标签，死亡图片;
    def __init__(self, img, pos, hp, speed, screen, tag, deadimgs):
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.topleft = pos
        self.hp = hp
        self.speed = speed
        self.screen = screen
        self.tag = tag
        self.deadimgs = deadimgs

        self.index = 0
        self.indexAdd1 = 0
        self.indexAdd2 = 0
        self.indexImg = 0
        self.move = 0

        enemyList.append(self)

    # 行为：移动
    def Move(self):
        self.indexAdd1 += 1
        if self.indexAdd1 == 1000:
            self.indexAdd1 = 0
        if self.indexAdd1 % 15 == 0:
            self.move += 1
        # 如果敌机血量小于等于0
        if self.hp <= 0:
            self.Dead()
        else:
            self.rect = self.rect.move(5 * math.sin(self.move), self.speed)
            self.screen.blit(self.image, self.rect)
            # 出画面死亡
            if self.rect.y >= 900:
                if self in enemyList:
                    enemyList.remove(self)

    # 行为：死亡
    def Dead(self):
        # 计算帧数
        self.indexAdd2 += 1
        if self.indexAdd2 == 1000:
            self.indexAdd2 = 0

        if self.tag == 'enemy1':
            musicList[0].play()
            if self.indexAdd2 % 3 == 0:
                self.indexImg += 1
                if self.indexImg == 4:
                    # 从列表中移除
                    if self in enemyList:
                        Hero.Score += 1
                        enemyList.remove(self)
        elif self.tag == 'enemy2':
            musicList[1].play()
            if self.indexAdd2 % 3 == 0:
                self.indexImg += 1
                if self.indexImg == 4:
                    # 从列表中移除
                    if self in enemyList:
                        Hero.Score += 3
                        enemyList.remove(self)
        elif self.tag == 'enemy3':
            musicList[2].play()
            if self.indexAdd2 % 4 == 0:
                self.indexImg += 1
                if self.indexImg == 4:
                    # 从列表中移除
                    if self in enemyList:
                        Hero.Score += 5
                        enemyList.remove(self)
        elif self.tag == 'enemy4':
            musicList[3].play()
            if self.indexAdd2 % 5 == 0:
                self.indexImg += 1
                if self.indexImg == 4:
                    # 从列表中移除
                    if self in enemyList:
                        Hero.Score += 10
                        enemyList.remove(self)
        elif self.tag == 'award1':
            # musicList[3].play()
            if self.indexAdd2 % 2 == 0:
                self.indexImg += 1
                if self.indexImg == 4:
                    # 从列表中移除
                    if self in enemyList:
                        Hero.Boom += 1
                        if Hero.Boom > 3:
                            Hero.Boom = 3
                        enemyList.remove(self)
        elif self.tag == 'award2':
            # musicList[3].play()
            if self.indexAdd2 % 2 == 0:
                self.indexImg += 1
                if self.indexImg == 4:
                    # 从列表中移除
                    if self in enemyList:
                        Hero.protect = True
                        enemyList.remove(self)
        else:
            # musicList[3].play()
            if self.indexAdd2 % 2 == 0:
                self.indexImg += 1
                if self.indexImg == 4:
                    # 从列表中移除
                    if self in enemyList:
                        Hero.protect = True
                        enemyList.remove(self)

        self.screen.blit(self.deadimgs[self.indexImg], self.rect)


# 敌机工厂类
class EnemyFactor:
    @staticmethod
    def CreatEnemy(screen):
        # 产生几率  敌机1：40%  敌机2：30%  敌机3：20%  敌机4：10%
        ranNum = random.randint(1, 1200)

        if ranNum < 400:
            Enemy(enemyImgs[0],
                  (random.randint(0, 426), -76), 1, 5, screen, "enemy1", enemy1Imgs)
        elif ranNum < 700:
            Enemy(enemyImgs[1],
                  (random.randint(0, 403), -139), 3, 3, screen, "enemy2", enemy2Imgs)
        elif ranNum < 900:
            Enemy(enemyImgs[2],
                  (random.randint(0, 284), -156), 5, 2, screen, "enemy3", enemy3Imgs)
        elif ranNum < 1000:
            Enemy(enemyImgs[3],
                  (random.randint(0, 296), -312), 10, 1, screen, "enemy4", enemy4Imgs)
        elif ranNum < 1100:
            Enemy(awardImgs[0],
                  (random.randint(0, 450), -31), 15, 3, screen, "award1", award1)
        else:
            Enemy(awardImgs[1],
                  (random.randint(0, 445), -64), 15, 3, screen, "award2", award2)


    @staticmethod
    def AllEnemyMove():
        for i in enemyList:
            if isinstance(i, Enemy):
                i.Move()


history = 0


# 历史最高分
class History:
    # 读取历史最高分函数
    def ReadHistory(path='score.txt'):
        global history
        if os.path.exists(path):
            with open(path, 'r') as f_r:
                history = f_r.read()
        else:
            with open(path, 'w') as f_w:
                f_w.write('0')

    # 更新历史最高分函数
    def UpdateHistory(score, path='score.txt'):
        if os.path.exists(path):
            with open(path, 'r') as file_r:
                if int(file_r.read()) < score:
                    with open(path, 'w') as file_w:
                        file_w.write(str(score))


# 初始化屏幕
screen = None


# 事件类
def AllEvent():
    global isPlay
    global screen
    # 迭代所有事件
    for i in pygame.event.get():

        # 判断鼠标是否按下
        if i.type == pygame.MOUSEBUTTONDOWN:

            # 判断鼠标是否点击“开始游戏”
            if i.button == 1 and StartPlane.isInside and isPlay != 1:
                # print('11111111111111')
                # 读取历史纪录
                History.ReadHistory()
                heroObj.hp = 1
                Hero.Score = 0
                isPlay = 1

        if i.type == pygame.USEREVENT + 1 and isPlay:
            EnemyFactor.CreatEnemy(screen)

        # 判断键盘按键是否按下
        if i.type == pygame.KEYDOWN:
            # 判断是否Esc退出游戏界面
            if i.key == pygame.K_ESCAPE:
                isPlay = 2
            # 判断上下左右
            if i.key == pygame.K_w:
                Hero.up = True
            if i.key == pygame.K_s:
                Hero.down = True
            if i.key == pygame.K_a:
                Hero.left = True
            if i.key == pygame.K_d:
                Hero.right = True
            # 空格全屏爆炸
            if i.key == pygame.K_SPACE and Hero.Boom > 0:
                for j in enemyList:
                    j.hp = 0
                Hero.Boom -= 1

        # 判断键盘按键是否抬起
        if i.type == pygame.KEYUP:
            # 判断上下左右
            if i.key == pygame.K_w:
                Hero.up = False
            if i.key == pygame.K_s:
                Hero.down = False
            if i.key == pygame.K_a:
                Hero.left = False
            if i.key == pygame.K_d:
                Hero.right = False

        # 判断事件是否为退出
        if i.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


# 主函数
def Main():
    # 初始化pygame、display
    pygame.init()
    pygame.display.init()

    # 创建窗口
    global screen
    screen = pygame.display.set_mode((506, 900))
    pygame.display.set_caption('')

    # 设置缩略图标
    iconImg = pygame.image.load('image/icon.png')
    pygame.display.set_icon(iconImg)

    # 开始界面对象
    startObj = StartPlane(screen)

    # 英雄对象
    global heroObj
    heroObj = Hero(shipRed, (202, 689), 10, 5, screen)

    # 字体
   # fontObj = pygame.font.Font('font/font9.ttf', 25)

    # 背景运动图像
    bgObj = BackGround(startImgs[0], 1, screen)

    # 判断是否开始游戏
    global isPlay
    isPlay = 0

    # 播放背景音乐
    pygame.mixer.music.load("music/Back.ogg")
    pygame.mixer.music.play(-1)

    # 设置计时器
    pygame.time.set_timer(pygame.USEREVENT + 1, 2000)

    clock = pygame.time.Clock()

    # 循环计算画面
    while True:
        # 监测事件
        AllEvent()

        if isPlay == 1:
            # 游戏运行
            bgObj.Move()
            EnemyFactor.AllEnemyMove()
            heroObj.Move()
            

        elif isPlay == 2:
            # 死亡界面
            startObj.EndDisp()
            enemyList.clear()
            bulletList.clear()

        else:
            # 开始界面
            startObj.StartDisp()

        # 更新画面
        pygame.display.update()

        # 每秒60帧
        clock.tick(60)


if __name__ == '__main__':
    Main()
